import unittest

from Task01.subsidy import (
    decision_exclusive,
    decision_match,
    decisions_separate,
    decisions_with_overlapping_bug,
    linear_slab_decision,
)


class SubsidyTests(unittest.TestCase):
    def test_all_boundaries(self) -> None:
        self.assertEqual(decision_exclusive(100, False, False), "full")
        self.assertEqual(decision_exclusive(101, True, False), "partial")
        self.assertEqual(decision_exclusive(200, True, False), "partial")
        self.assertEqual(decision_exclusive(201, False, True), "elder")

    def test_exclusive_alternatives_agree(self) -> None:
        for units in (0, 100, 101, 200, 201, 1000):
            for card in (False, True):
                for elder in (False, True):
                    expected = decision_exclusive(units, card, elder)
                    self.assertEqual(decision_match(units, card, elder), expected)
                    self.assertEqual(linear_slab_decision(units, card, elder), expected)

    def test_correct_separate_ranges_are_disjoint(self) -> None:
        self.assertEqual(decisions_separate(100, True, True), ["full"])
        self.assertEqual(decisions_separate(101, True, True), ["partial"])

    def test_overlapping_condition_bug_can_produce_two_results(self) -> None:
        self.assertEqual(
            decisions_with_overlapping_bug(100, True, False), ["full", "partial"]
        )

    def test_negative_units_rejected_by_exclusive_forms(self) -> None:
        with self.assertRaises(ValueError):
            decision_exclusive(-1, False, False)


if __name__ == "__main__":
    unittest.main()
