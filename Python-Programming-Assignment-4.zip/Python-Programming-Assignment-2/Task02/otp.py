"""OTP attempt loops with blank-input handling and loop-else lockout."""

from collections.abc import Iterable


def _attempt_limit(security_question_correct: bool) -> int:
    return 5 if security_question_correct else 3


def verify_with_while(
    entries: Iterable[str], correct_otp: str, *, security_question_correct: bool = False
) -> tuple[bool, int, bool]:
    """Return (verified, nonblank_attempts, locked) using while/else."""
    iterator = iter(entries)
    attempts = 0
    limit = _attempt_limit(security_question_correct)
    while attempts < limit:
        try:
            entry = next(iterator)
        except StopIteration:
            break
        if not entry.strip():
            continue
        if not entry.isdigit():
            pass  # A nonblank malformed response is still a failed OTP attempt.
        attempts += 1
        if entry == correct_otp:
            return True, attempts, False
    else:
        return False, attempts, True
    return False, attempts, False


def verify_with_for(
    entries: Iterable[str], correct_otp: str, *, security_question_correct: bool = False
) -> tuple[bool, int, bool]:
    """Return (verified, nonblank_attempts, locked) using for/else."""
    attempts = 0
    limit = _attempt_limit(security_question_correct)
    for entry in entries:
        if not entry.strip():
            continue
        if not entry.isdigit():
            pass
        attempts += 1
        if entry == correct_otp:
            return True, attempts, False
        if attempts == limit:
            break
    else:
        return False, attempts, False
    return False, attempts, attempts == limit


def verify_recursive(
    entries: Iterable[str], correct_otp: str, *, security_question_correct: bool = False
) -> tuple[bool, int, bool]:
    """Recursive alternative; a long input uses one Python frame per entry."""
    responses = tuple(entries)
    limit = _attempt_limit(security_question_correct)

    def attempt(index: int, attempts: int) -> tuple[bool, int, bool]:
        if attempts == limit:
            return False, attempts, True
        if index == len(responses):
            return False, attempts, False
        entry = responses[index]
        if not entry.strip():
            return attempt(index + 1, attempts)
        if not entry.isdigit():
            pass
        attempts += 1
        if entry == correct_otp:
            return True, attempts, False
        return attempt(index + 1, attempts)

    return attempt(0, 0)


def main() -> None:
    samples = [
        (["", "111111", "222222", "123456"], False),
        (["111111", "", "222222", "333333"], False),
        (["111111", "222222", "333333", "", "123456"], True),
    ]
    for entries, security_ok in samples:
        print(
            f"security={security_ok}: while={verify_with_while(entries, '123456', security_question_correct=security_ok)}; "
            f"for={verify_with_for(entries, '123456', security_question_correct=security_ok)}; "
            f"recursive={verify_recursive(entries, '123456', security_question_correct=security_ok)}"
        )


if __name__ == "__main__":
    main()
