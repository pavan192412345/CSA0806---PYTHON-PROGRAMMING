import unittest

from Task05.functions_scope import (
    add_item,
    add_item_buggy,
    make_order_adder,
    make_counter,
    price_with_gst,
)


class FunctionsScopeTests(unittest.TestCase):
    def test_safe_default_creates_independent_orders(self) -> None:
        self.assertEqual(add_item("Tea"), ["Tea"])
        self.assertEqual(add_item("Vada"), ["Vada"])

    def test_explicit_order_is_mutated_and_returned(self) -> None:
        order = ["Idli"]
        self.assertIs(add_item("Tea", order), order)
        self.assertEqual(order, ["Idli", "Tea"])

    def test_buggy_default_is_shared(self) -> None:
        add_item_buggy.__defaults__[0].clear()
        first = add_item_buggy("Tea")
        second = add_item_buggy("Vada")
        self.assertIs(first, second)
        self.assertEqual(second, ["Tea", "Vada"])
        add_item_buggy.__defaults__[0].clear()

    def test_multiple_return_values_and_nonlocal_scope(self) -> None:
        self.assertEqual(price_with_gst(100), (105, 5))
        counter = make_counter()
        self.assertEqual((counter(), counter()), (1, 2))

    def test_closure_state_is_separate_per_customer(self) -> None:
        customer_one = make_order_adder()
        customer_two = make_order_adder()
        self.assertEqual(customer_one("Tea"), ["Tea"])
        self.assertEqual(customer_two("Vada"), ["Vada"])


if __name__ == "__main__":
    unittest.main()
