"""Q2: bounded OTP attempts."""
