import unittest

from Task07.redesign import measure_iterative, measure_memo, measure_naive


class RedesignTests(unittest.TestCase):
    def test_redesigns_match_original_for_same_inputs(self) -> None:
        for n in (0, 1, 5, 10):
            expected = measure_naive(n)[0]
            self.assertEqual(measure_memo(n)[0], expected)
            self.assertEqual(measure_iterative(n)[0], expected)

    def test_call_counts_show_reduced_repeated_work(self) -> None:
        naive = measure_naive(10)
        memo = measure_memo(10)
        self.assertGreater(naive[1], memo[1])
        self.assertEqual(memo[1], 11)


if __name__ == "__main__":
    unittest.main()
