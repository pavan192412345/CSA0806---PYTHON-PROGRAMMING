import unittest

from Task02.otp import verify_recursive, verify_with_for, verify_with_while


class OtpTests(unittest.TestCase):
    def test_blank_entries_do_not_count(self) -> None:
        self.assertEqual(verify_with_while(["", "  ", "123456"], "123456"), (True, 1, False))
        self.assertEqual(verify_with_for(["", "  ", "123456"], "123456"), (True, 1, False))
        self.assertEqual(verify_recursive(["", "  ", "123456"], "123456"), (True, 1, False))

    def test_three_wrong_entries_lock(self) -> None:
        entries = ["111111", "222222", "333333", "123456"]
        self.assertEqual(verify_with_while(entries, "123456"), (False, 3, True))
        self.assertEqual(verify_with_for(entries, "123456"), (False, 3, True))
        self.assertEqual(verify_recursive(entries, "123456"), (False, 3, True))

    def test_security_answer_grants_two_extra_attempts(self) -> None:
        entries = ["111111", "222222", "333333", "444444", "123456"]
        self.assertEqual(
            verify_with_while(entries, "123456", security_question_correct=True),
            (True, 5, False),
        )
        self.assertEqual(
            verify_with_for(entries, "123456", security_question_correct=True),
            (True, 5, False),
        )
        self.assertEqual(
            verify_recursive(entries, "123456", security_question_correct=True),
            (True, 5, False),
        )

    def test_exhausted_input_is_not_mistaken_for_lockout(self) -> None:
        self.assertEqual(verify_with_while(["111111"], "123456"), (False, 1, False))
        self.assertEqual(verify_with_for(["111111"], "123456"), (False, 1, False))
        self.assertEqual(verify_recursive(["111111"], "123456"), (False, 1, False))


if __name__ == "__main__":
    unittest.main()
