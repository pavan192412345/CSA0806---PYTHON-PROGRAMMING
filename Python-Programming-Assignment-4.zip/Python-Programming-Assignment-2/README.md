# Python Programming Assignment 2

**Student name:** [Your Name]  
**Register number:** [Your Register Number]  
**Python version used for validation:** Python 3.11.0 (standard library only)  
**GitHub repository:** https://github.com/ArshadKhanM/Python-Programming-Assignment-2

This project contains runnable examples for Q1–Q7. Replace the student
placeholders before submission. The assignment asks for predictions,
measurements, and personal analysis; benchmark results depend on the machine,
so run the commands below and record your own observations in your report.
The prepared report is in [`report/assignment_report.md`](report/assignment_report.md).

## Contents

| Task | Topic | Run |
| --- | --- | --- |
| Q1 | Subsidy boundaries and decision structures | `python -m Task01.subsidy` |
| Q2 | OTP attempts, loops, and loop `else` | `python -m Task02.otp` |
| Q3 | Vehicle registration strings | `python -m Task03.registration` |
| Q4 | String building and timing | `python -m Task04.string_building` |
| Q5 | Parameters, mutable defaults, and scope | `python -m Task05.functions_scope` |
| Q6 | Recursive, memoized, and iterative stair counts | `python -m Task06.stair_ways` |
| Q7 | Measure and redesign the stair-count solution | `python -m Task07.redesign` |

Run all unit tests from this directory:

```powershell
python -m unittest discover -v
```

Run Q4's 1,000-, 10,000-, and 200,000-line benchmark (three trials per size):

```powershell
python -m Task04.string_building --benchmark
```

Run Q7's original-versus-redesigned measurements:

```powershell
python -m Task07.redesign
```

## Design and complexity notes

- **Q1:** The exact stated unit ranges are disjoint, so correctly bounded
  separate `if` statements do not overlap. The demo also shows how omitting a
  lower boundary creates two results; ordered `if`/`elif` still prevents
  multiple branches from firing. With a fixed number of rules either takes
  O(1) time and space. A `match` is O(1) for these cases; a linear scan of k
  slabs takes O(k) time and the slab table takes O(k) space.
- **Q2:** Blank entries are ignored, wrong nonblank entries consume attempts,
  and loop `else` handles exhaustion without a successful `break`. The maximum
  can increase from three to five after a correct security answer. Both loop
  approaches use O(a) time and O(1) extra space for `a` attempts; a recursive
  alternative is implemented and uses O(a) call-stack space.
- **Q3:** Normalisation and validation use string operations and slices, not
  regular expressions. For input length L, both are O(L) time; the normalized
  result uses O(L) additional space. Python strings are immutable, so
  `upper()` returns a new string rather than modifying its receiver.
- **Q4:** Repeated concatenation can copy an increasing prefix on each step,
  giving O(n²) worst-case work. Joining n parts is O(n) time and needs storage
  for the parts plus final result. The `StringIO` example avoids constructing
  intermediate joined prefixes; writing directly to a file avoids retaining
  the entire statement in memory.
- **Q5:** A `None` default avoids sharing a mutable list between calls.
  Appending is O(1) amortized; each independent order uses O(m) space for m
  items. Passing the list explicitly or creating one closure per customer can
  also isolate state.
- **Q6/Q7:** Plain recursion takes O(phi^n) time and O(n) stack space.
  Memoisation takes O(n) time and O(n) cache/stack space. The iterative
  redesign takes O(n) time and O(1) auxiliary space. Recursive memoisation
  near n=1,000 may hit Python's recursion limit; the loop avoids that limit.

## Submission evidence

The programs print example results and the benchmark scripts print raw
measurements. Re-run them on your computer and update the report's timing
tables before submission; do not treat machine-dependent timings as universal.
