"""Q6: recursion and its limits."""
