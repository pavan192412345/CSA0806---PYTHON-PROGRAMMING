# Assignment 2 report

**Student name:** [Your Name]  
**Register number:** [Your Register Number]  
**Python:** 3.11.0

Timings below were recorded on the machine used to prepare this project. They
are evidence for this run, not promised timings on other computers. Re-run the
commands in the README and replace the timing tables with your own results
before submission.

## Q1 — Decisions with boundaries

Predicted boundary outcomes: 100 units gives full subsidy; 101 and 200 give
partial subsidy only with a ration card; 201 gives the elder exception only
when an over-80 household member is present. The eight example households are
executed by `python -m Task01.subsidy`.

The stated ranges themselves are disjoint, so correctly bounded independent
`if` checks produce one result. Multiple results occur if a condition is
written too broadly: the demonstration deliberately omits the lower bound on
the partial-subsidy condition, so a household at 100 units with a ration card
matches both full and partial. An ordered `if`/`elif` chain stops after its
first match. Either fixed decision tree takes O(1) time and O(1) space; a
linear scan over k decision slabs takes O(k) time and O(k) table space.

## Q2 — OTP attempts

The `while`, `for`, and recursive examples ignore blank input, count each
nonblank wrong OTP, stop on a correct OTP, and distinguish exhausted input
from three failed attempts. A successful security answer raises the limit to
five. For a finite attempt sequence, all three return the same result. A
`while` loop is natural when the limit or continuation condition changes while
processing; a misplaced counter increment can skip or grant an attempt.
`break` stops after success or lockout, `continue` ignores blanks, and `pass`
is a deliberate no-op before malformed nonblank input is treated as a failed
attempt. Loop `else` runs when the loop reaches its limit/exhaustion without a
`break`. The iterative forms use O(a) time and O(1) extra space; recursion
uses O(a) stack space.

## Q3 — Registration strings

Predictions for the examples: `tn 09 ab 1234` and `KA-01-M-0007` normalize to
valid plates; `Tn09Ab1234` is valid after uppercasing; `TN9AB1234` has the
wrong district width; `TN 22 1234 AB` has fields in the wrong order; and
`A1-09-AB-1234` has a non-letter state character. These results and receipt
formatting are printed by `python -m Task03.registration`.

Strings are immutable: `text.upper()` produces another string and leaves
`text` unchanged. The slice `s[-4:]` always selects the final four characters.
For a 9-character value, `s[4:-4]` selects one series character; for a
10-character value, it selects two. Normalizing/validating a string of length
L is O(L) time and O(L) additional space.

## Q4 — Building long statements

Prediction: `join` should outperform repeated concatenation as the number of
lines grows because it constructs the result in one pass instead of
repeatedly extending a prefix. All four builders (`+=`, `join`, per-line
f-string, and `StringIO`) return the same text.

Average seconds over three runs:

| Lines | `+=` | `join` | f-string | `StringIO` |
| ---: | ---: | ---: | ---: | ---: |
| 1,000 | 0.000138 | 0.000009 | 0.000086 | 0.000080 |
| 10,000 | 0.001263 | 0.000166 | 0.000637 | 0.000681 |
| 200,000 | 0.593298 | 0.009184 | 0.039314 | 0.026763 |

Repeated concatenation can copy an increasing prefix (O(n²) worst-case
characters copied); joining n parts is O(n) time. `StringIO` is convenient
when appending incrementally but retains the assembled result in memory.
Writing each line to a file can avoid keeping the entire output in memory,
at the cost of file I/O.

## Q5 — Parameters and scope

The shared mutable default is created once when the function is defined;
calling the buggy function for two customers therefore returns the same list.
Using `None` and allocating a new list inside the function fixes the leak.
The demonstration prints the mutated `__defaults__` tuple. It also shows an
explicit order, positional/keyword/default parameters, a `(total, GST)` return
tuple, local names, a global update requiring `global`, and a closure whose
state is isolated per customer. Adding an item is O(1) amortized; an order
containing m items uses O(m) space.

## Q6 — Recursion and limits

The recurrence is `ways(n) = ways(n-1) + ways(n-2)` with base values 1 for
n=0 or n=1. The verified counts for n=1 through 6 are 1, 2, 3, 5, 8, 13.
For n=5, the call tree branches as `ways(5) -> ways(4), ways(3)`,
`ways(4) -> ways(3), ways(2)`, `ways(3) -> ways(2), ways(1)`, and
`ways(2) -> ways(1), ways(0)`; repeated `ways(3)` and `ways(2)` calls show
the redundant work.

At n=25, the naive implementation makes 242,785 calls, while memoisation
computes 26 distinct states; both return 121,393. Memoisation reduces work to
O(n) but holds O(n) cache entries and uses recursive stack space. The
memoized call at n=1,000 exceeds this interpreter's recursion limit (1,000);
the iterative version completes and returns a 209-digit answer. The iterative
solution takes O(n) time and O(1) auxiliary space, so it is the deployment
choice for the requested upper bound.

## Q7 — Diagnose, redesign, validate

**Original:** naive recursion recalculates the same subproblems repeatedly.
At n=30 it makes 2,692,537 calls, making the call count the main measurable
limitation.

**Objective:** preserve the answer while reducing work from exponential
repeated calls to linear work, and handle n=1,000 without hitting the
recursion limit.

**Redesign:** memoisation stores each computed state once; the iterative
version keeps only the last two values. Both exploit the recurrence, replacing
recomputation with a cache or two rolling variables. The cache costs O(n)
space; the iterative loop uses O(1) auxiliary space.

**Prediction:** all versions return the same count, but memoisation and the
loop make O(n) state updates rather than O(phi^n) calls; the loop should use
less memory and avoid recursion failure.

Measurements for equal inputs:

| n | Version | Result | Counted work | Seconds |
| ---: | --- | ---: | ---: | ---: |
| 10 | Naive | 89 | 177 | 0.000027 |
| 10 | Memoized | 89 | 11 | 0.000010 |
| 10 | Loop | 89 | 10 | 0.000007 |
| 20 | Naive | 10,946 | 21,891 | 0.002938 |
| 20 | Memoized | 10,946 | 21 | 0.000061 |
| 20 | Loop | 10,946 | 20 | 0.000012 |
| 25 | Naive | 121,393 | 242,785 | 0.026137 |
| 25 | Memoized | 121,393 | 26 | 0.000163 |
| 25 | Loop | 121,393 | 25 | 0.000017 |
| 30 | Naive | 1,346,269 | 2,692,537 | 0.360411 |
| 30 | Memoized | 1,346,269 | 31 | 0.000055 |
| 30 | Loop | 1,346,269 | 30 | 0.000011 |

The objective was met: the answers agree, and the redesign reduces counted
work substantially. Timings are noisy at small sizes, so operation counts and
the n=30 comparison are stronger evidence. Naive recursion remains useful for
teaching the recurrence on small inputs; the iterative redesign is preferred
for larger n because it is fast, bounded in auxiliary memory, and avoids the
recursion limit.
