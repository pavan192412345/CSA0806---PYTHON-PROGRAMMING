"""Q5: functions, parameters, and scope."""
