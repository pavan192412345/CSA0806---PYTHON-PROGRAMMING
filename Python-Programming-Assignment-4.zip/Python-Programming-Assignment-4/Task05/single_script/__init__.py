"""Single-file organization."""
