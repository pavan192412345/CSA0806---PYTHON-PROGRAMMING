"""Q1: decisions with multiple boundaries."""
