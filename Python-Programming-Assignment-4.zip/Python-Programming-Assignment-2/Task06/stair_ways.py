"""Count ways to climb stairs by taking one or two steps."""

from functools import lru_cache
import sys

calls = 0


def ways_naive(n: int) -> int:
    """Plain exponential recursion; suitable only for small n."""
    global calls
    if n < 0:
        return 0
    calls += 1
    if n <= 1:
        return 1
    return ways_naive(n - 1) + ways_naive(n - 2)


@lru_cache(maxsize=None)
def ways_memo(n: int) -> int:
    """Memoized recurrence; cache contains one result per distinct n."""
    global calls
    if n < 0:
        return 0
    calls += 1
    if n <= 1:
        return 1
    return ways_memo(n - 1) + ways_memo(n - 2)


def ways_iterative(n: int) -> int:
    """Compute the same recurrence with O(1) auxiliary space."""
    if n < 0:
        raise ValueError("n cannot be negative")
    previous, current = 1, 1
    for _ in range(n):
        previous, current = current, previous + current
    return previous


def main() -> None:
    global calls
    print("by hand check n=1..6:", [ways_iterative(n) for n in range(1, 7)])
    calls = 0
    print("naive n=25:", ways_naive(25), "calls =", calls)
    ways_memo.cache_clear()
    calls = 0
    print("memo n=25:", ways_memo(25), "calls =", calls)
    print("iterative n=1000 digits:", len(str(ways_iterative(1000))))
    print("recursion limit:", sys.getrecursionlimit())
    ways_memo.cache_clear()
    try:
        ways_memo(1000)
    except RecursionError:
        print("memo n=1000 exceeded the recursion limit; use the iterative version.")


if __name__ == "__main__":
    main()
