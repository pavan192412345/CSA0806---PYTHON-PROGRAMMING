"""Q3: vehicle registration string operations."""
