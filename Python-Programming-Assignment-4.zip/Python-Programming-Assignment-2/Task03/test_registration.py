import unittest

from Task03.registration import format_receipt, is_valid, normalise


class RegistrationTests(unittest.TestCase):
    def test_normalizes_spaces_hyphens_and_case(self) -> None:
        self.assertEqual(normalise("tn 09 ab 1234"), "TN09AB1234")
        self.assertEqual(normalise("KA-01-M-0007"), "KA01M0007")

    def test_valid_forms_and_receipt(self) -> None:
        self.assertTrue(is_valid("TN09AB1234"))
        self.assertTrue(is_valid("KA01M0007"))
        self.assertEqual(format_receipt("tn 09 ab 1234"), "TN 09 AB 1234")

    def test_invalid_length_order_and_non_ascii(self) -> None:
        for value in ("TN9AB1234", "TN221234AB", "A1-09-AB-1234", "தமிழ்09AB1234"):
            self.assertFalse(is_valid(value))
        self.assertFalse(is_valid(None))  # type: ignore[arg-type]

    def test_format_rejects_invalid_input(self) -> None:
        with self.assertRaises(ValueError):
            format_receipt("TN9AB1234")


if __name__ == "__main__":
    unittest.main()
