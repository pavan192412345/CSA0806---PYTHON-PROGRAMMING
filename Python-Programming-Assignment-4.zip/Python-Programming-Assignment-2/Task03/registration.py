"""Normalize, validate, and print vehicle registration numbers."""


def normalise(text: str) -> str:
    """Remove spaces and hyphens, then uppercase the input."""
    return text.strip().upper().replace(" ", "").replace("-", "")


def is_valid(reg: str) -> bool:
    """Accept 2 letters, 2 digits, 1-2 letters, then 4 digits."""
    if not isinstance(reg, str):
        return False
    value = normalise(reg)
    if len(value) not in (9, 10):
        return False
    series_end = len(value) - 4
    return (
        value[0:2].isalpha()
        and value[0:2].isascii()
        and value[2:4].isdigit()
        and value[2:4].isascii()
        and value[4:series_end].isalpha()
        and value[4:series_end].isascii()
        and value[series_end:].isdigit()
        and value[series_end:].isascii()
    )


def format_receipt(reg: str) -> str:
    """Format a valid registration as STATE DISTRICT SERIES NUMBER."""
    value = normalise(reg)
    if not is_valid(value):
        raise ValueError("Registration number is invalid.")
    series_end = len(value) - 4
    return f"{value[:2]} {value[2:4]} {value[4:series_end]} {value[series_end:]}"


def main() -> None:
    examples = [
        "tn 09 ab 1234",
        "KA-01-M-0007",
        "Tn09Ab1234",
        "TN9AB1234",
        "TN 22 1234 AB",
        "A1-09-AB-1234",
    ]
    for raw in examples:
        value = normalise(raw)
        if is_valid(value):
            print(f"{raw:16} -> {value:10} valid  {format_receipt(value)}")
        else:
            print(f"{raw:16} -> {value:10} INVALID")


if __name__ == "__main__":
    main()
