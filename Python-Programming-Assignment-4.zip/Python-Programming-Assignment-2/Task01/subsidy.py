"""Compare separate if statements with an exclusive if/elif decision."""

from collections.abc import Callable


def decisions_separate(units: int, has_ration_card: bool, has_over_80_member: bool) -> list[str]:
    """Return all matching decisions; overlapping conditions can yield several."""
    decisions: list[str] = []
    if units <= 100:
        decisions.append("full")
    if 101 <= units <= 200 and has_ration_card:
        decisions.append("partial")
    if units > 200 and has_over_80_member:
        decisions.append("elder")
    if not decisions:
        decisions.append("none")
    return decisions


def decisions_with_overlapping_bug(
    units: int, has_ration_card: bool, has_over_80_member: bool
) -> list[str]:
    """Illustrate a separate-if bug caused by omitting the lower slab boundary."""
    decisions: list[str] = []
    if units <= 100:
        decisions.append("full")
    if units <= 200 and has_ration_card:
        decisions.append("partial")
    if units > 200 and has_over_80_member:
        decisions.append("elder")
    if not decisions:
        decisions.append("none")
    return decisions


def decision_exclusive(units: int, has_ration_card: bool, has_over_80_member: bool) -> str:
    """Return exactly one decision using ordered mutually exclusive branches."""
    if units < 0:
        raise ValueError("Units cannot be negative.")
    if units <= 100:
        return "full"
    elif units <= 200:
        return "partial" if has_ration_card else "none"
    elif has_over_80_member:
        return "elder"
    return "none"


def decision_match(units: int, has_ration_card: bool, has_over_80_member: bool) -> str:
    """Alternative match-case formulation for Python 3.10+."""
    if units < 0:
        raise ValueError("Units cannot be negative.")
    match (units <= 100, units <= 200, has_ration_card, has_over_80_member):
        case (True, _, _, _):
            return "full"
        case (False, True, True, _):
            return "partial"
        case (False, True, False, _):
            return "none"
        case (False, False, _, True):
            return "elder"
        case _:
            return "none"


def linear_slab_decision(units: int, has_ration_card: bool, has_over_80_member: bool) -> str:
    """Example O(k) ordered upper-limit lookup."""
    if units < 0:
        raise ValueError("Units cannot be negative.")
    slabs: list[tuple[int | None, Callable[[], str]]] = [
        (100, lambda: "full"),
        (200, lambda: "partial" if has_ration_card else "none"),
        (None, lambda: "elder" if has_over_80_member else "none"),
    ]
    for upper_limit, decide in slabs:
        if upper_limit is None or units <= upper_limit:
            return decide()
    raise AssertionError("The final open-ended slab must match.")


def main() -> None:
    households = [
        (100, False, False),
        (101, True, False),
        (200, True, False),
        (201, False, True),
        (201, False, False),
        (80, True, True),
        (150, False, True),
        (0, False, False),
    ]
    print("units card elder | separate-if results | exclusive result")
    for units, card, elder in households:
        separate = decisions_separate(units, card, elder)
        exclusive = decision_exclusive(units, card, elder)
        print(f"{units:5} {str(card):4} {str(elder):5} | {separate!s:21} | {exclusive}")
    print("overlapping-condition example at 100 units with a card:",
          decisions_with_overlapping_bug(100, True, False))


if __name__ == "__main__":
    main()
