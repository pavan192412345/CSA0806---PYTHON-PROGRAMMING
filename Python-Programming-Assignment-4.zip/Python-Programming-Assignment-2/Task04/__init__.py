"""Q4: building long strings."""
