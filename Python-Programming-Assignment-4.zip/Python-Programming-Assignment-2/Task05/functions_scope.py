"""Demonstrate safe mutable defaults, returning values, and name scope."""

from collections.abc import Callable


def add_item_buggy(item: str, order: list[str] = []) -> list[str]:
    """Intentionally buggy: the same default list is reused across calls."""
    order.append(item)
    return order


def add_item(item: str, order: list[str] | None = None) -> list[str]:
    if order is None:
        order = []
    order.append(item)
    return order


def make_order_adder() -> Callable[[str], list[str]]:
    """Return an adder with order state isolated to this closure."""
    order: list[str] = []

    def add(item: str) -> list[str]:
        order.append(item)
        return order

    return add


def price_with_gst(amount: float, gst_rate: float = 0.05) -> tuple[float, float]:
    """Return (total including GST, GST amount)."""
    gst = amount * gst_rate
    return amount + gst, gst


def make_counter() -> Callable[[], int]:
    count = 0

    def increment() -> int:
        nonlocal count
        count += 1
        return count

    return increment


GLOBAL_VISITS = 0


def record_global_visit() -> int:
    global GLOBAL_VISITS
    GLOBAL_VISITS += 1
    return GLOBAL_VISITS


def main() -> None:
    print("buggy:", add_item_buggy("Tea"), add_item_buggy("Vada"))
    print("fixed:", add_item("Tea"), add_item("Vada"))
    print("buggy defaults:", add_item_buggy.__defaults__)
    print("total, GST:", price_with_gst(100, gst_rate=0.05))
    customer_one = make_order_adder()
    customer_two = make_order_adder()
    print("closure orders:", customer_one("Tea"), customer_two("Vada"))
    counter = make_counter()
    print("nonlocal counter:", counter(), counter())
    print("global visits:", record_global_visit())


if __name__ == "__main__":
    main()
