"""Three-module attendance organization."""
