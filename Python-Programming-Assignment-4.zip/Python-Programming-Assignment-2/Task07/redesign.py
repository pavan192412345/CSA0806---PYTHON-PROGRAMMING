"""Compare the original recursive stair counter with efficient redesigns."""

import time

from Task06 import stair_ways


def measure_naive(n: int) -> tuple[int, int, float]:
    stair_ways.calls = 0
    start = time.perf_counter()
    result = stair_ways.ways_naive(n)
    elapsed = time.perf_counter() - start
    return result, stair_ways.calls, elapsed


def measure_memo(n: int) -> tuple[int, int, float]:
    stair_ways.ways_memo.cache_clear()
    stair_ways.calls = 0
    start = time.perf_counter()
    result = stair_ways.ways_memo(n)
    elapsed = time.perf_counter() - start
    return result, stair_ways.calls, elapsed


def measure_iterative(n: int) -> tuple[int, int, float]:
    start = time.perf_counter()
    result = stair_ways.ways_iterative(n)
    return result, n, time.perf_counter() - start


def main() -> None:
    print("n | version | result | counted work | seconds")
    for n in (10, 20, 25, 30):
        original = measure_naive(n)
        memoized = measure_memo(n)
        iterative = measure_iterative(n)
        if not (original[0] == memoized[0] == iterative[0]):
            raise AssertionError(f"implementations disagree for n={n}")
        for name, row in (("naive", original), ("memo", memoized), ("loop", iterative)):
            print(f"{n:2} | {name:6} | {row[0]:10} | {row[1]:12} | {row[2]:.6f}")


if __name__ == "__main__":
    main()
