"""Compare repeated concatenation, join, and f-string line construction."""

import argparse
from io import StringIO
import time
from collections.abc import Callable, Sequence


def build_plus(parts: Sequence[str]) -> str:
    text = ""
    for part in parts:
        text += part + ";"
    return text


def build_join(parts: Sequence[str]) -> str:
    return ";".join(parts) + (";" if parts else "")


def build_fstring(parts: Sequence[str]) -> str:
    return "".join(f"{part};" for part in parts)


def build_stringio(parts: Sequence[str]) -> str:
    buffer = StringIO()
    for part in parts:
        buffer.write(part)
        buffer.write(";")
    return buffer.getvalue()


def _average_seconds(builder: Callable[[Sequence[str]], str], parts: Sequence[str], trials: int) -> float:
    elapsed = 0.0
    for _ in range(trials):
        start = time.perf_counter()
        builder(parts)
        elapsed += time.perf_counter() - start
    return elapsed / trials


def benchmark(sizes: Sequence[int] = (1_000, 10_000, 200_000), trials: int = 3) -> None:
    if trials < 1:
        raise ValueError("trials must be at least one")
    builders = (
        ("+= ", build_plus),
        ("join", build_join),
        ("f-string", build_fstring),
        ("StringIO", build_stringio),
    )
    for size in sizes:
        parts = [f"Item{i}:Rs{i % 50}" for i in range(size)]
        expected = build_join(parts)
        print(f"\n{size:,} lines (average of {trials} trials)")
        for name, builder in builders:
            result = builder(parts)
            if result != expected:
                raise AssertionError(f"{name} produced different output")
            print(f"{name:9}: {_average_seconds(builder, parts, trials):.6f} s")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--benchmark", action="store_true", help="time three sizes, three runs each")
    args = parser.parse_args()
    if args.benchmark:
        benchmark()
        return
    items = [f"Item{i}:Rs{i % 50}" for i in range(10)]
    plus, joined = build_plus(items), build_join(items)
    formatted, buffered = build_fstring(items), build_stringio(items)
    print("same output:", plus == joined == formatted == buffered)
    print("sample:", joined[:90])


if __name__ == "__main__":
    main()
