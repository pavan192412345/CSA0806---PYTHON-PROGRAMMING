import unittest

from Task04.string_building import build_fstring, build_join, build_plus, build_stringio


class StringBuildingTests(unittest.TestCase):
    def test_builders_create_identical_text(self) -> None:
        for parts in ([], ["one"], ["one", "two", "three"]):
            expected = build_join(parts)
            self.assertEqual(build_plus(parts), expected)
            self.assertEqual(build_fstring(parts), expected)
            self.assertEqual(build_stringio(parts), expected)

    def test_join_preserves_trailing_separator(self) -> None:
        self.assertEqual(build_join(["a", "b"]), "a;b;")


if __name__ == "__main__":
    unittest.main()
