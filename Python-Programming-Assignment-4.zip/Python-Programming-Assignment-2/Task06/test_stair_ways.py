import unittest

from Task06 import stair_ways


class StairWaysTests(unittest.TestCase):
    def setUp(self) -> None:
        stair_ways.calls = 0
        stair_ways.ways_memo.cache_clear()

    def test_small_values(self) -> None:
        self.assertEqual([stair_ways.ways_iterative(n) for n in range(1, 7)], [1, 2, 3, 5, 8, 13])
        self.assertEqual(stair_ways.ways_naive(5), 8)

    def test_memoization_avoids_repeated_subproblems(self) -> None:
        self.assertEqual(stair_ways.ways_memo(25), 121393)
        self.assertEqual(stair_ways.calls, 26)

    def test_iterative_handles_one_thousand_steps(self) -> None:
        value = stair_ways.ways_iterative(1000)
        self.assertGreater(len(str(value)), 200)

    def test_negative_input(self) -> None:
        with self.assertRaises(ValueError):
            stair_ways.ways_iterative(-1)


if __name__ == "__main__":
    unittest.main()
