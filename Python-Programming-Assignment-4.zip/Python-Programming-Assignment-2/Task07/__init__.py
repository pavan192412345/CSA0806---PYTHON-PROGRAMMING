"""Q7: diagnose, redesign, and validate."""
